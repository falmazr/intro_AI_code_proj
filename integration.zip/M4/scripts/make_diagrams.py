"""Draw the two report diagrams as PNGs: the two-tier pipeline and the module architecture.

    python scripts/make_diagrams.py   -> results/figures/pipeline.png, results/figures/architecture.png
"""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch  # noqa: E402

OUT = Path(__file__).resolve().parents[1] / "results" / "figures"
INK, EDGE, ACCENT, TINT = "#222222", "#7a7a7a", "#2a78d6", "#eef3fb"


def box(ax, x, y, w, h, title, sub="", accent=False, fill="white"):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.08",
                                fc=(TINT if accent else fill), ec=(ACCENT if accent else EDGE), lw=1.8 if accent else 1.2))
    two = "\n" in sub
    ax.text(x + w / 2, y + h / 2 + (0.2 if two else 0.09 if sub else 0), title, ha="center", va="center",
            fontsize=10.5, fontweight="bold", color=INK)
    if sub:
        ax.text(x + w / 2, y + h / 2 - (0.15 if two else 0.11), sub, ha="center", va="center", fontsize=8.5,
                color="#555555", linespacing=1.1)


def arrow(ax, p, q, label="", rad=0.0, ls="-"):
    ax.add_patch(FancyArrowPatch(p, q, arrowstyle="-|>", mutation_scale=14, lw=1.3, color=EDGE, ls=ls,
                                 connectionstyle=f"arc3,rad={rad}"))
    if label:
        mx, my = (p[0] + q[0]) / 2, (p[1] + q[1]) / 2
        ax.text(mx, my + 0.12, label, ha="center", va="bottom", fontsize=8.5, color="#555555")


def pipeline():
    fig, ax = plt.subplots(figsize=(10, 4.6))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4.4)
    ax.axis("off")
    ax.set_title("Two-tier planner: one abstract search, then one confined search per area boundary",
                 loc="left", fontsize=11.5)
    # preprocessing band
    ax.add_patch(FancyBboxPatch((0.2, 2.35), 2.6, 1.6, boxstyle="round,pad=0.02", fc="#f3f3f3", ec="none"))
    ax.text(0.35, 3.8, "once per map", fontsize=8.5, color="#555555")
    box(ax, 0.4, 2.6, 2.2, 0.95, "Build area graph", "areas, portals, weights")
    box(ax, 3.4, 2.6, 2.4, 0.95, "Tier 1: abstract A*", "area(s) -> area(g), weight W0 / W1 / W2")
    box(ax, 6.6, 2.6, 2.4, 0.95, "Area sequence", "A1, A2, ..., Am")
    box(ax, 6.6, 0.5, 2.4, 0.95, "Tier 2: one A* per leg", "confined to At and At+1", accent=True)
    box(ax, 2.9, 0.5, 2.5, 0.95, "Concatenated path", "cost, nodes expanded (both tiers)")
    arrow(ax, (2.6, 3.07), (3.4, 3.07))
    arrow(ax, (5.8, 3.07), (6.6, 3.07))
    arrow(ax, (7.8, 2.6), (7.8, 1.45), "per query")
    arrow(ax, (6.6, 0.97), (5.4, 0.97), "all legs found")
    ax.plot([9.0, 9.5, 9.5, 4.6], [0.97, 0.97, 4.05, 4.05], color=EDGE, lw=1.3, ls="--")
    arrow(ax, (4.6, 4.05), (4.6, 3.55), ls="--")
    ax.text(7.0, 4.15, "a leg fails: ban that area edge and re-plan", fontsize=8.5, color="#555555", ha="center")
    fig.tight_layout()
    fig.savefig(OUT / "pipeline.png", dpi=170)
    plt.close(fig)


def architecture():
    fig, ax = plt.subplots(figsize=(10, 5.2))
    ax.set_xlim(0, 10)
    ax.set_ylim(-0.15, 5.2)
    ax.axis("off")
    ax.set_title("Module architecture: four interfaces let four people work in parallel", loc="left", fontsize=11.5)
    # layer bands
    for y, name in ((3.95, "world"), (2.45, "search"), (0.95, "planners"), (-0.0, "")):
        pass
    box(ax, 0.3, 3.9, 2.0, 0.85, "grid.py", "Grid, .map format,\nneighbours(), area_of()")
    box(ax, 2.7, 3.9, 2.0, 0.85, "partition.py", "label_areas, A1 split,\nAreaGraph, portals")
    box(ax, 5.1, 3.9, 2.0, 0.85, "generator.py", "rooms_and_corridors,\nuniform_blocks, random_query")
    box(ax, 7.5, 3.9, 2.2, 0.85, "maps/, scripts/", "figure1.map, warehouse.map,\nmake_warehouse.py")
    box(ax, 0.3, 2.45, 2.0, 0.85, "search.py", "astar(), bfs(),\nSearchResult")
    box(ax, 2.7, 2.45, 2.0, 0.85, "heuristics.py", "manhattan, octile,\nmin_to_set")
    box(ax, 5.1, 2.45, 2.0, 0.85, "planners/base.py", "Planner.prepare/plan,\nregistry make()", accent=True)
    box(ax, 7.5, 2.45, 2.2, 0.85, "smoothing.py", "corridor_refine")
    box(ax, 0.3, 1.0, 2.0, 0.85, "planners/flat.py", "FlatAStar, BFS,\nDijkstra, WeightedAStar")
    box(ax, 2.7, 1.0, 2.0, 0.85, "planners/twotier.py", "TwoTierPlanner\nW0/W1, legs, fallback")
    box(ax, 5.1, 1.0, 2.0, 0.85, "planners/hpa.py", "HPAPlanner (W2),\nportal distances")
    box(ax, 7.5, 1.0, 2.2, 0.85, "viz.py, cli.py", "render, animate,\nmls show/plan/generate")
    box(ax, 0.3, 0.0, 4.4, 0.6, "experiments/run.py, analyze.py", "seeded, resumable CSV; stats, figures")
    box(ax, 5.1, 0.0, 4.6, 0.6, "tests/ (68) + CI", "Figure 1 example, fallback, pipeline smoke")
    # arrows: who calls whom (a few, not all)
    for x in (1.3, 3.7, 6.1):
        arrow(ax, (x, 1.85), (x, 2.45))
    arrow(ax, (2.3, 3.0), (2.7, 3.0))
    arrow(ax, (4.7, 2.87), (5.1, 2.87))
    arrow(ax, (3.7, 3.9), (3.7, 3.3))
    arrow(ax, (1.3, 3.9), (1.3, 3.3))
    arrow(ax, (2.5, 0.6), (3.7, 1.0))
    arrow(ax, (7.3, 0.6), (6.1, 1.0))
    ax.text(0.3, 4.95, "M1 world & partition", fontsize=8.5, color=ACCENT)
    ax.text(2.0, 3.45, "M2 search & planners", fontsize=8.5, color=ACCENT)
    ax.text(5.1, 3.45, "M3 variants & experiments", fontsize=8.5, color=ACCENT)
    ax.text(7.5, 2.0, "M4 visualisation, CLI, QA", fontsize=8.5, color=ACCENT)
    fig.tight_layout()
    fig.savefig(OUT / "architecture.png", dpi=170)
    plt.close(fig)


if __name__ == "__main__":
    OUT.mkdir(parents=True, exist_ok=True)
    pipeline()
    architecture()
    print("wrote", OUT / "pipeline.png", "and", OUT / "architecture.png")

"""Command-line interface.

    mls show     maps/figure1.map                      # ASCII map + area graph summary
    mls plan     maps/warehouse.map 5 2 50 37 --planner twotier --planner astar
    mls generate 128 --seed 3 --rooms 5 -o maps/gen128.map
    mls render   maps/warehouse.map 5 2 50 37 -o results/figures/warehouse_demo.png
    mls animate  maps/figure1.map 0 0 7 7 -o results/figures/fig1_anim

Installed as ``mls`` via ``pip install -e .`` or run as ``python -m mls.cli``.
"""

from __future__ import annotations

import argparse
import random
import sys
import time
from pathlib import Path

from .generator import RoomSpec, rooms_and_corridors, uniform_blocks
from .grid import Grid
from .partition import build_area_graph
from .planners import PLANNERS, make

PLANNER_SPECS = {
    "astar": ("astar", {}), "bfs": ("bfs", {}), "dijkstra": ("dijkstra", {}),
    "wastar": ("wastar", {"epsilon": 1.5}),
    "twotier": ("twotier", {"weight_model": "W1", "leg_goal": "first"}),
    "twotier-W0": ("twotier", {"weight_model": "W0", "leg_goal": "first"}),
    "twotier-nearest": ("twotier", {"weight_model": "W1", "leg_goal": "nearest"}),
    "twotier-W2": ("twotier-W2", {}),
}


def _planner(spec: str):
    name, kwargs = PLANNER_SPECS[spec]
    return make(name, **kwargs)


def cmd_show(a) -> None:
    g = Grid.load(a.map)
    ag = build_area_graph(g)
    print(g.render())
    print()
    print(ag.describe() if a.verbose else ag.describe().splitlines()[0])


def cmd_plan(a) -> None:
    g = Grid.load(a.map, connectivity=a.connectivity)
    s, t = (a.sx, a.sy), (a.gx, a.gy)
    for spec in a.planner or ["astar", "twotier"]:
        p = _planner(spec)
        t0 = time.perf_counter()
        p.prepare(g)
        tp = (time.perf_counter() - t0) * 1000
        t0 = time.perf_counter()
        r = p.plan(s, t)
        tq = (time.perf_counter() - t0) * 1000
        if r.success:
            areas = r.extra.get("areas")
            via = (" via " + " > ".join(p.graph.names.get(x, str(x)) for x in areas)) if areas and hasattr(p, "graph") else ""
            print(f"{p.name:>18}: cost {r.cost:g}, {r.expanded} expanded, {r.generated} generated, "
                  f"prep {tp:.1f} ms, query {tq:.2f} ms{via}")
            if a.show:
                print(g.render(r.path, s, t))
        else:
            print(f"{p.name:>18}: no path ({r.expanded} expanded)")


def cmd_generate(a) -> None:
    g = rooms_and_corridors(a.size, random.Random(a.seed), RoomSpec(rooms_per_side=a.rooms))
    if a.blocks:
        g = uniform_blocks(g, a.blocks)
    if a.output:
        g.save(a.output)
        ag = build_area_graph(g)
        print(f"wrote {a.output}: {g.count_free()} free cells, {len(ag.areas)} areas, {len(ag.edges)} edges")
    else:
        print(g.dumps())


def cmd_render(a) -> None:
    from .viz import side_by_side
    g = Grid.load(a.map)
    planners = [_planner(s) for s in (a.planner or ["astar", "twotier"])]
    out = Path(a.output or "results/figures/render.png")
    side_by_side(g, planners, (a.sx, a.sy), (a.gx, a.gy), out, suptitle=a.title or Path(a.map).name)
    print(f"wrote {out}")


def cmd_animate(a) -> None:
    from .viz import animate_two_tier
    g = Grid.load(a.map)
    frames = animate_two_tier(g, _planner("twotier"), (a.sx, a.sy), (a.gx, a.gy), Path(a.output or "results/figures/anim"))
    print(f"wrote {len(frames)} frames to {frames[0].parent}")


def main(argv=None) -> None:
    ap = argparse.ArgumentParser(prog="mls", description="Multi-layered search on grid worlds")
    sub = ap.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("show", help="print a map and its area graph")
    s.add_argument("map")
    s.add_argument("-v", "--verbose", action="store_true")
    s.set_defaults(fn=cmd_show)

    def query_args(p):
        p.add_argument("map")
        p.add_argument("sx", type=int)
        p.add_argument("sy", type=int)
        p.add_argument("gx", type=int)
        p.add_argument("gy", type=int)
        p.add_argument("--planner", action="append", choices=sorted(PLANNER_SPECS))

    p = sub.add_parser("plan", help="plan one query with one or more planners")
    query_args(p)
    p.add_argument("--connectivity", type=int, default=4, choices=(4, 8))
    p.add_argument("--show", action="store_true", help="print the path on the map")
    p.set_defaults(fn=cmd_plan)

    gpar = sub.add_parser("generate", help="generate a rooms-and-corridors map")
    gpar.add_argument("size", type=int)
    gpar.add_argument("--seed", type=int, default=0)
    gpar.add_argument("--rooms", type=int, default=3, help="rooms per side")
    gpar.add_argument("--blocks", type=int, default=0, help="relabel into BxB uniform blocks")
    gpar.add_argument("-o", "--output")
    gpar.set_defaults(fn=cmd_generate)

    r = sub.add_parser("render", help="PNG with one panel per planner (expanded cells + path)")
    query_args(r)
    r.add_argument("-o", "--output")
    r.add_argument("--title")
    r.set_defaults(fn=cmd_render)

    an = sub.add_parser("animate", help="PNG frames (+GIF) of the two-tier planner, leg by leg")
    query_args(an)
    an.add_argument("-o", "--output")
    an.set_defaults(fn=cmd_animate)

    a = ap.parse_args(argv)
    a.fn(a)


if __name__ == "__main__":
    main(sys.argv[1:])

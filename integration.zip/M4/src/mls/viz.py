"""Rendering grids, areas, expanded cells and paths with matplotlib.

Used by the CLI (``mls render``) for report figures and the demo. Each area
gets its own colour; blocked cells are dark; expanded cells are shaded; the
path is drawn as a line with start and goal markers.

An optional step-by-step animation of the two-tier planner is produced by
``animate_two_tier`` as a sequence of PNG frames (and a GIF if Pillow is
installed), which is what we show in the demonstration.
"""

from __future__ import annotations

from pathlib import Path
from typing import Iterable, Sequence

from .grid import Cell, Grid
from .partition import AreaGraph, build_area_graph
from .search import SearchResult


def _mpl():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    return plt


def area_image(grid: Grid, graph: AreaGraph):
    """RGB float array (height, width, 3) with one colour per area, y = 0 at the bottom row."""
    import colorsys
    import numpy as np

    img = np.full((grid.height, grid.width, 3), 0.18)  # blocked = dark grey
    k = max(1, len(graph.areas))
    # Golden-angle hue stepping gives neighbours distinct hues without a lookup table.
    for idx, a in enumerate(graph.areas):
        hue = (idx * 0.618033988749895) % 1.0
        r, g, b = colorsys.hls_to_rgb(hue, 0.82, 0.55)
        for x, y in graph.cells[a]:
            img[y, x] = (r, g, b)
    return img


def render(grid: Grid, graph: AreaGraph | None = None, result: SearchResult | None = None,
           start: Cell | None = None, goal: Cell | None = None, expanded: Iterable[Cell] = (),
           title: str = "", ax=None, show_area_labels: bool = True):
    """Draw one grid. Returns the matplotlib Axes."""
    plt = _mpl()
    import numpy as np

    if graph is None:
        graph = build_area_graph(grid)
    if ax is None:
        _, ax = plt.subplots(figsize=(6, 6 * grid.height / grid.width))
    img = area_image(grid, graph)
    ex = list(expanded)
    for x, y in ex:
        img[y, x] = img[y, x] * 0.55 + np.array([0.25, 0.25, 0.45]) * 0.45
    ax.imshow(img, origin="lower", interpolation="nearest",
              extent=(-0.5, grid.width - 0.5, -0.5, grid.height - 0.5))
    if show_area_labels and grid.width <= 64:
        for a in graph.areas:
            cx, cy = graph.centroid[a]
            ax.text(cx, cy, graph.names.get(a, str(a)), ha="center", va="center", fontsize=8, color="#222222")
    if result is not None and result.path:
        xs = [c[0] for c in result.path]
        ys = [c[1] for c in result.path]
        ax.plot(xs, ys, color="#111111", lw=1.8 if grid.width <= 64 else 1.0)
        start, goal = result.path[0], result.path[-1]
    if start is not None:
        ax.plot(start[0], start[1], marker="o", ms=8, color="#2a78d6", mec="white")
    if goal is not None:
        ax.plot(goal[0], goal[1], marker="*", ms=12, color="#e34948", mec="white")
    ax.set_xticks([])
    ax.set_yticks([])
    if title:
        ax.set_title(title, fontsize=10, loc="left")
    return ax


def expanded_cells(grid: Grid, planner, start: Cell, goal: Cell) -> tuple[SearchResult, list[Cell]]:
    """Run ``planner`` while recording every cell whose neighbours were requested (= expanded)."""
    seen: list[Cell] = []
    original = grid.neighbours

    def tracing(c: Cell):
        seen.append(c)
        return original(c)

    grid.neighbours = tracing  # type: ignore[method-assign]
    try:
        r = planner.plan(start, goal)
    finally:
        del grid.neighbours  # restore the class method
    return r, seen


def side_by_side(grid: Grid, planners: Sequence, start: Cell, goal: Cell, out: Path, suptitle: str = "") -> None:
    """One panel per planner: expanded cells shaded, path drawn, stats in the title."""
    plt = _mpl()
    graph = build_area_graph(grid)
    fig, axes = plt.subplots(1, len(planners), figsize=(5.2 * len(planners), 5.4 * grid.height / grid.width + 0.6))
    if len(planners) == 1:
        axes = [axes]
    for ax, p in zip(axes, planners):
        p.prepare(grid)
        r, ex = expanded_cells(grid, p, start, goal)
        title = f"{p.name}: cost {r.cost:.0f}, {r.expanded} expanded" if r.success else f"{p.name}: no path"
        render(grid, graph, r, start, goal, expanded=ex, title=title, ax=ax)
    if suptitle:
        fig.suptitle(suptitle, x=0.02, ha="left", fontsize=11)
    fig.tight_layout()
    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out, dpi=160)
    plt.close(fig)


def animate_two_tier(grid: Grid, planner, start: Cell, goal: Cell, outdir: Path, gif: bool = True) -> list[Path]:
    """Frames: the abstract route, then each refinement leg accumulating. Needs TwoTierPlanner."""
    plt = _mpl()
    planner.prepare(grid)
    graph = planner.graph
    r = planner.plan(start, goal)
    outdir.mkdir(parents=True, exist_ok=True)
    frames: list[Path] = []
    areas = r.extra.get("areas", [])
    # Frame 0: the abstract route (areas highlighted by drawing their centroids joined)
    fig, ax = plt.subplots(figsize=(6, 6 * grid.height / grid.width))
    render(grid, graph, None, start, goal, title="Tier 1: area sequence " +
           " > ".join(graph.names.get(a, str(a)) for a in areas), ax=ax)
    cx = [graph.centroid[a][0] for a in areas]
    cy = [graph.centroid[a][1] for a in areas]
    ax.plot(cx, cy, color="#111111", lw=2, ls="--", marker="s", ms=6)
    f0 = outdir / "frame_00.png"
    fig.savefig(f0, dpi=140)
    plt.close(fig)
    frames.append(f0)
    # Then the legs
    if r.path:
        boundaries = [0]
        for i in range(1, len(r.path)):
            if grid.area_of(r.path[i]) != grid.area_of(r.path[i - 1]):
                boundaries.append(i)
        boundaries.append(len(r.path) - 1)
        for k in range(1, len(boundaries)):
            fig, ax = plt.subplots(figsize=(6, 6 * grid.height / grid.width))
            partial = SearchResult(r.path[: boundaries[k] + 1], 0, 0, 0, 0)
            render(grid, graph, partial, start, goal, title=f"Tier 2: leg {k} of {len(boundaries) - 1}", ax=ax)
            fk = outdir / f"frame_{k:02d}.png"
            fig.savefig(fk, dpi=140)
            plt.close(fig)
            frames.append(fk)
    if gif:
        try:
            from PIL import Image
            ims = [Image.open(f) for f in frames]
            ims[0].save(outdir / "two_tier.gif", save_all=True, append_images=ims[1:], duration=900, loop=0)
        except ImportError:
            pass
    return frames

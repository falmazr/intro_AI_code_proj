# M4: append these two tests to the END of tests/test_pipeline.py (M3 created the file).

def test_cli_plan_and_show(capsys):
    from mls.cli import main
    main(["show", str(ROOT / "maps" / "figure1.map")])
    main(["plan", str(ROOT / "maps" / "figure1.map"), "0", "0", "7", "7", "--planner", "astar", "--planner", "twotier"])
    out = capsys.readouterr().out
    assert "5 areas, 5 edges" in out and "cost 14" in out and "via M > Y > W" in out


def test_viz_renders(tmp_path):
    from mls.viz import side_by_side
    g = Grid.load(ROOT / "maps" / "figure1.map")
    out = tmp_path / "fig1.png"
    side_by_side(g, [make("astar"), make("twotier")], (0, 0), (7, 7), out)
    assert out.exists() and out.stat().st_size > 1000

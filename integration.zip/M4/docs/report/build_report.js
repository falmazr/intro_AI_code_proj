// Builds CSCI218_Topic4_Report.docx from the project results.
const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, Table, TableRow, TableCell,
  WidthType, ImageRun, PageBreak, LevelFormat, ShadingType, BorderStyle, TableOfContents, Footer, PageNumber,
} = require("docx");

const REPO = path.resolve(__dirname, "..", "multilayer-search");
const FIG = (n) => path.join(REPO, "results", "figures", n);
const FONT = "Calibri";

// ---------------------------------------------------------------- helpers
const t = (text, opts = {}) => new TextRun({ text, font: FONT, size: 22, ...opts });
// inline markup: **bold**, *italic*, `code`
function rich(s, base = {}) {
  const runs = [];
  const re = /(\*\*[^*]+\*\*|\/\/[^/]+\/\/|`[^`]+`)/g;
  let last = 0, m;
  while ((m = re.exec(s))) {
    if (m.index > last) runs.push(t(s.slice(last, m.index), base));
    const tok = m[0];
    if (tok.startsWith("**")) runs.push(t(tok.slice(2, -2), { ...base, bold: true }));
    else if (tok.startsWith("`")) runs.push(new TextRun({ text: tok.slice(1, -1), font: "Consolas", size: 19, ...base }));
    else runs.push(t(tok.slice(2, -2), { ...base, italics: true }));
    last = m.index + tok.length;
  }
  if (last < s.length) runs.push(t(s.slice(last), base));
  return runs;
}
const P = (s, opts = {}) => new Paragraph({ children: rich(s), spacing: { after: 120, line: 276 }, ...opts });
const H1 = (s) => new Paragraph({ text: s, heading: HeadingLevel.HEADING_1 });
const H2 = (s) => new Paragraph({ text: s, heading: HeadingLevel.HEADING_2 });
const H3 = (s) => new Paragraph({ text: s, heading: HeadingLevel.HEADING_3 });
const bullets = (items) => items.map((s) => new Paragraph({ children: rich(s), numbering: { reference: "bul", level: 0 }, spacing: { after: 60, line: 264 } }));
let numRef = 0;
const numbered = (items) => { numRef++; return items.map((s) => new Paragraph({ children: rich(s), numbering: { reference: `num${numRef}`, level: 0 }, spacing: { after: 60, line: 264 } })); };
const code = (lines) => lines.map((l) => new Paragraph({ children: [new TextRun({ text: l, font: "Consolas", size: 18 })], spacing: { after: 0, line: 240 }, shading: { type: ShadingType.CLEAR, fill: "F3F3F3" }, indent: { left: 360 } }));
const pageBreak = () => new Paragraph({ children: [new PageBreak()] });
const caption = (s, keep = false) => new Paragraph({ children: rich(s, { size: 19, color: "444444" }), alignment: AlignmentType.CENTER, spacing: { before: 60, after: keep ? 80 : 240 }, keepNext: keep });
let figN = 0, tabN = 0;
function figure(file, cap, widthIn = 6.2) {
  figN++;
  const buf = fs.readFileSync(FIG(file));
  const { width, height } = pngSize(buf);
  const w = Math.round(widthIn * 96), h = Math.round((height / width) * w);
  return [
    new Paragraph({ children: [new ImageRun({ type: "png", data: buf, transformation: { width: w, height: h } })], alignment: AlignmentType.CENTER, spacing: { before: 120 }, keepNext: true }),
    caption(`**Figure ${figN}.** ${cap}`),
  ];
}
function pngSize(buf) { return { width: buf.readUInt32BE(16), height: buf.readUInt32BE(20) }; }
function table(header, rows, widths, cap, opts = {}) {
  tabN++;
  const total = widths.reduce((a, b) => a + b, 0);
  const cell = (s, isHead, w, align) => new TableCell({
    width: { size: w, type: WidthType.DXA },
    shading: isHead ? { type: ShadingType.CLEAR, fill: "E8EEF7" } : undefined,
    margins: { top: 50, bottom: 50, left: 80, right: 80 },
    children: [new Paragraph({ children: rich(String(s), { size: opts.size || 19, bold: isHead }), alignment: align || AlignmentType.LEFT, spacing: { after: 0 } })],
  });
  const mk = (r, isHead) => new TableRow({ tableHeader: isHead, children: r.map((c, i) => cell(c, isHead, widths[i], i >= (opts.rightFrom ?? 1) && opts.rightAlign ? AlignmentType.RIGHT : AlignmentType.LEFT)) });
  return [
    caption(`**Table ${tabN}.** ${cap}`, true),
    new Table({ width: { size: total, type: WidthType.DXA }, columnWidths: widths, rows: [mk(header, true), ...rows.map((r) => mk(r, false))] }),
    new Paragraph({ spacing: { after: 160 } }),
  ];
}
const W = 9360; // text width in DXA for A4 with 2.5 cm margins... we use 2 cm: 21cm-4cm = 17cm = 9638; keep 9360

// ---------------------------------------------------------------- content
const body = [];

// Title page
body.push(
  new Paragraph({ spacing: { before: 2400 } }),
  new Paragraph({ children: [t("CSCI218 Foundations of Artificial Intelligence", { size: 26, color: "555555" })], alignment: AlignmentType.CENTER }),
  new Paragraph({ children: [t("Group Project Report, Autumn 2026", { size: 26, color: "555555" })], alignment: AlignmentType.CENTER, spacing: { after: 600 } }),
  new Paragraph({ children: [t("Multi-Layered Search for Warehouse Robot Path Planning", { size: 40, bold: true })], alignment: AlignmentType.CENTER, spacing: { after: 200 } }),
  new Paragraph({ children: [t("A two-tiered search over areas and cells, compared with flat A* on grids from 8×8 to 512×512", { size: 26, italics: true, color: "333333" })], alignment: AlignmentType.CENTER, spacing: { after: 900 } }),
  new Paragraph({ children: [t("Topic 4 — Multi-Layered Search", { size: 24 })], alignment: AlignmentType.CENTER }),
  new Paragraph({ children: [t("Group: [group name]", { size: 24 })], alignment: AlignmentType.CENTER, spacing: { after: 300 } }),
  ...["Member 1 (M1): [name], [student ID] — world, partition, maps", "Member 2 (M2): [name], [student ID] — search core and planners", "Member 3 (M3): [name], [student ID] — variants, experiments, analysis", "Member 4 (M4): [name], [student ID] — visualisation, CLI, QA, report"].map((s) => new Paragraph({ children: [t(s, { size: 22 })], alignment: AlignmentType.CENTER, spacing: { after: 60 } })),
  new Paragraph({ children: [t("Repository: https://github.com/[org]/multilayer-search   Commit: [hash]", { size: 20, color: "555555" })], alignment: AlignmentType.CENTER, spacing: { before: 600 } }),
  new Paragraph({ children: [t("University of Wollongong in Dubai", { size: 22 })], alignment: AlignmentType.CENTER, spacing: { before: 200 } }),
  pageBreak(),
  new Paragraph({ text: "Contents", heading: HeadingLevel.HEADING_1 }),
  new TableOfContents("Contents", { hyperlink: true, headingStyleRange: "1-2" }),
  pageBreak(),
);

// (a) Executive summary
body.push(H1("(a) Executive summary"));
body.push(P("Path planning for a mobile robot on a large floor becomes expensive when every query searches over every cell: at one-inch resolution a building floor has millions of cells, and the number of nodes a flat A* search expands grows roughly with the square of the distance between start and goal. This project formalises, implements and evaluates a **two-tiered (hierarchical) search** that exploits the structure a floor already has. Tier 1 plans over a small graph of //areas// (rooms, aisles, cross-aisles, dock aprons); Tier 2 runs a sequence of small cell-level A* searches, each confined to two adjacent areas, and concatenates them. We implemented the planner in Python with three abstract edge-weight models (W0 hop count, W1 centroid distance, W2 precomputed portal distances in the style of HPA*), together with flat A*, breadth-first search, Dijkstra and Weighted A* as baselines, a seeded map generator, a hand-designed 60×40 logistics-warehouse map, and a reproducible experiment pipeline."));
body.push(P("On 6 grid sizes × 5 maps × 30 queries (9,000 instances, 4-connected), the two-tier W1 planner expands **27× fewer nodes** than flat A* at 512×512 (626 ± 31 vs 16,922 ± 3,189, mean ± 95% CI) and answers queries **7× faster** (8.1 ms vs 58.3 ms), at a mean path-cost overhead of 0.9 % (worst 16 %). It beats flat A* on nodes from 16×16 and on runtime from 32×32. The W2 variant returns the **optimal path on every one of the 9,000 queries** while still expanding 7× fewer nodes and running 11× faster than flat A* at 512×512. A paired sign test confirms the node saving on 147 of 150 queries at 512×512 (p < 10⁻³⁹)."));
body.push(P("The method's weakness is the partition it is given. On the hand-built warehouse map, whose cross-aisles are long thin areas, the centroid weight mis-ranks routes and W1 paths are 10.8 % longer than optimal on average (worst 96 %), whereas W2 remains optimal. Classic HPA* on uniform 16×16 blocks is never faster than flat A* on our maps. An ablation attributes the W1 overhead to the choice of area route rather than to local detours: a corridor-refinement post-process changes nothing, and the two leg-goal rules give identical paths. We conclude that semantic areas with precomputed portal distances (W2) are the right configuration when optimality matters and preprocessing can be amortised, and W1 when speed matters most."));

// (b) Motivation
body.push(H1("(b) Motivation and problem definition"));
body.push(H2("Scenario: a mobile robot on a logistics-warehouse floor"));
body.push(P("Our real-world scenario is a fleet of mobile robots in a logistics warehouse: goods arrive at inbound docks, are put away in racking aisles or bulk-storage floors, picked, brought to packing and shipped from outbound docks. Each robot re-plans a path many times a minute as pick lists change and as other robots block aisles. Figure 1 shows the floor we modelled: 60 m × 40 m at 1 m per cell, with a receiving apron (R), three cross-aisles (S, M, N), eighteen racking aisles (a–r), two bulk-storage floors (B, U), packing (P), a dispatch apron (D), a charging bay (H) and an office block (O). The project brief describes the same problem at one-inch resolution for a university building; a 60 m × 40 m floor at that resolution is 2,362 × 1,575 ≈ 3.7 million cells, which is why per-query cost matters."));
body.push(...figure("warehouse_demo.png", "The warehouse map (60×40, 1 m per cell) with one query from receiving (10,2) to dispatch (50,37). Left: flat A*, 113 nodes expanded. Middle: two-tier W1 through areas R > S > q > M > h > N > D, 90 nodes. Right: two-tier W2, 434 nodes because its start/goal insertion searches flood the receiving and dispatch areas. All three paths cost 75. Shaded cells were expanded; colours are areas."));
body.push(H2("Why a hierarchy"));
body.push(P("A warehouse operator routes by areas (\"down the south cross-aisle, up aisle q, across the middle cross-aisle to aisle h, then to dispatch\"), not cell by cell. A planner that does the same should expand work proportional to the number of areas on the route rather than to the start–goal distance squared, should need only a tiny abstract search when the route changes, and should be able to re-plan a single leg when an aisle is blocked. These are exactly the properties the two-tiered search in the brief is designed to have, and the ones we set out to measure."));
body.push(H2("Problem statement"));
body.push(P("Given a rectangular grid of free and blocked cells whose perimeter is blocked, a partition of the free cells into areas, a start cell and a goal cell, find a path of adjacent free cells from start to goal. Compare a two-tiered search, which first chooses a sequence of areas and then plans within them, against a flat single-level A* on three measures as the grid grows: nodes expanded, runtime, and path cost."));
body.push(H2("Measurable objectives"));
body.push(...numbered([
  "**Completeness:** find a path on 100 % of solvable instances.",
  "**Efficiency:** expand at least 5× fewer nodes than flat A* on 256×256 rooms-and-corridors maps.",
  "**Quality:** keep the mean ratio of two-tier path cost to optimal below 1.10 on the same maps, and report its distribution.",
  "**Crossover:** identify the grid size below which flat A* remains faster, and explain why.",
]));
body.push(H2("Scope"));
body.push(P("Static maps; 4-connected unit-cost moves for all headline results (an 8-connected variant with octile heuristic is implemented and evaluated in Section (f.8)); the area partition is given with the map or produced by our generator; a single robot. Dynamic replanning and multi-robot coordination are discussed as future work."));

// (c) Technical requirements
body.push(H1("(c) Technical requirements"));
body.push(P("Table 1 lists the functional requirements derived from the brief and how each is met and verified in the repository."));
body.push(...table(["#", "Requirement", "How it is met and verified"], [
  ["R1", "Accept any rectangular grid with blocked cells and an area label on every free cell; the perimeter is treated as blocked", "`.map` text format; cells outside the rectangle are blocked by definition; `tests/test_grid.py`"],
  ["R2", "Tolerate an imperfect partition: every area must be connected before search", "`split_disconnected_areas` enforces assumption A1; tested on a deliberately broken map"],
  ["R3", "A flat baseline that is complete and optimal", "A* with Manhattan heuristic (consistent); agrees with BFS and Dijkstra on every query in `tests/test_search.py` and in all 9,000 experiment instances"],
  ["R4", "A two-tiered planner: abstract search over areas, then confined cell-level searches", "`TwoTierPlanner` (W0/W1) and `HPAPlanner` (W2); the Figure 1 example of the brief reproduces entry cells (3,2) and (7,4) and cost 14"],
  ["R5", "Completeness even when a refinement leg fails", "Banned-edge re-plan, then flat A* fallback; `test_fallback_on_a_map_that_violates_a1`"],
  ["R6", "Metrics: nodes expanded, nodes generated, peak open-list size, runtime, path cost, cost ratio", "`SearchResult` carries the counters; `experiments/run.py` records every metric per query"],
  ["R7", "A scaling study on grids of increasing size with fixed random seeds", "Seeded generator; `configs/experiment.json` fixes sizes 16–512, seeds, queries"],
  ["R8", "Reproducibility: one command regenerates every table and figure", "`python -m experiments.run && python -m experiments.analyze`; CI runs the test suite and a smoke run on every push"],
  ["R9", "A visual demonstration of both tiers", "`mls render` (side-by-side expansions) and `mls animate` (leg-by-leg frames and GIF)"],
], [600, 3800, 4960], "Functional requirements and their verification."));
body.push(P("Non-functional requirements: Python 3.10 or later; the standard library only for all search code (numpy, matplotlib and Pillow are used for analysis and figures); deterministic tie-breaking so that node counts are reproducible; runtime measured as the median of three timed calls on one machine (Intel Xeon 2.30 GHz, Linux, CPython 3.13; recorded in `results/environment.txt`); no use of `hash()` or the global `random` module, both of which vary between processes."));

// (d) Main constructs
body.push(H1("(d) Main constructs"));
body.push(H2("d.1 Grid world"));
body.push(P("A world is W = (Wd, Ht, B, a). A cell is c = (x, y) with 0 ≤ x < Wd and 0 ≤ y < Ht; y increases upwards, so the lower-left cell is (0, 0) as in Figure 1 of the brief. B is the set of blocked cells and F the set of free cells; every cell outside the rectangle is blocked, which represents the brief's enclosing perimeter without shifting coordinates. N(c) is the set of free cells sharing an edge with c (4-connectivity). The area function a: F → {1, …, k} assigns every free cell to exactly one area. **Assumption A1:** every area is 4-connected. A map that violates A1 is repaired in preprocessing by splitting each area into its connected components and relabelling, so A1 always holds at search time."));
body.push(H2("d.2 The flat (cell-level) search problem"));
body.push(...table(["Element", "Definition"], [
  ["State", "a free cell c ∈ F"], ["Initial state", "s = (x_s, y_s)"], ["Actions", "move to any c′ ∈ N(c)"],
  ["Transition", "Result(c, move to c′) = c′"], ["Step cost", "1 per move (√2 for a diagonal move in the 8-connected variant)"],
  ["Goal test", "c = g"], ["Path cost", "the number of moves"],
], [2400, 6960], "The flat search problem."));
body.push(P("The state space has |F| states and branching factor at most 4. Flat A* uses the evaluation function f(n) = g(n) + h(n) with the Manhattan distance h(c) = |x_c − x_g| + |y_c − y_g|, which is admissible (every path needs at least that many unit moves) and consistent (one move changes h by at most 1, the step cost). With a consistent heuristic, A* with a closed set is complete and optimal and never re-expands a node. For 8-connectivity we use the octile distance max(dx, dy) + (√2 − 1)·min(dx, dy), which is admissible and consistent for that move set."));
body.push(H2("d.3 The area graph"));
body.push(P("The area graph is the abstract state space. Its nodes are the areas. A **portal** between areas i and j is a pair of adjacent free cells (u, v) with a(u) = i and a(v) = j; P(i, j) is the set of all such pairs. Areas i and j are joined by an (undirected) edge iff P(i, j) is non-empty. The **entry set** Entry(i, j) = {v : (u, v) ∈ P(i, j)} is the set of cells of j that can be stepped into directly from i. The graph is built in one O(|F|) pass that visits every free cell and its right and upper neighbours, recording portals in both directions. Each area also records its cell list and centroid. For Figure 1 of the brief the graph has five nodes and five edges: magenta–yellow, magenta–pink, yellow–white, pink–white and blue–yellow (blue is a dead end off yellow through (5,1)–(5,2); it does not touch magenta because (3,0) and (3,1) are walls). P(magenta, yellow) = {((2,2), (3,2))} and P(yellow, white) = {((7,3), (7,4))}, which are the entry cells named in the brief."));
body.push(...figure("figure1_demo.png", "Figure 1 of the brief, 8×8, S = (0,0) in magenta, G = (7,7) in white. Left: flat A*, 14 nodes expanded. Right: two-tier W1, area sequence M > Y > W through entry cells (3,2) and (7,4), 16 nodes expanded. Both paths cost 14, the Manhattan distance, so the two-tier path is optimal here.", 5.6));
body.push(H2("d.4 The abstract search problem (Tier 1)"));
body.push(...table(["Element", "Definition"], [
  ["State", "an area i"], ["Initial state", "a(s)"], ["Actions", "move to a neighbouring area j with (i, j) an edge"],
  ["Step cost", "w(i, j): W0 = 1; W1 = Manhattan distance between the centroids of i and j; W2 = exact in-area shortest distance between the portal cell used to enter i and a portal cell into j (see d.7)"],
  ["Goal test", "i = a(g)"], ["Solution", "an area sequence π = (A₁ = a(s), A₂, …, A_m = a(g))"],
], [2400, 6960], "The abstract search problem."));
body.push(P("The abstract heuristic is h_abs(i) = Manhattan(closest cell of area i to g, g), the minimum over the cells of i of the Manhattan distance to the goal (computed once per area and cached per query). It is admissible under W1 and W2 because any real path from any cell of i to g is at least that long; under W0 the hop count is not comparable with distances, so h = 0 (Dijkstra) is used. The abstract state space has k states; for the warehouse k = 28, and for a 512×512 generated map k ≈ 626, against 150,000–260,000 cells."));
body.push(H2("d.5 The refinement problems (Tier 2)"));
body.push(P("Given π, the planner solves m − 1 legs and a final leg. Leg t starts at the cell p_t where the previous leg ended (p₁ = s):"));
body.push(...table(["Element", "Definition"], [
  ["State", "a free cell c with a(c) ∈ {A_t, A_{t+1}}: the search is confined to the current area and the next one"],
  ["Initial state", "p_t"],
  ["Goal test", "a(c) = A_{t+1} (any cell of the next area; a multi-goal test), or c = the nearest entry cell under the alternative rule"],
  ["Heuristic", "h_leg(c) = min over v ∈ Entry(A_t, A_{t+1}) of Manhattan(c, v): admissible because the leg ends at some entry cell, consistent because a minimum of consistent heuristics is consistent"],
  ["Step cost", "1"],
], [2400, 6960], "One refinement leg."));
body.push(P("The final leg runs from p_m to g confined to A_m with goal test c = g. The full path is the concatenation of the legs and its cost is the sum of their costs; nodes expanded are summed over the abstract search and every leg, so the comparison with flat A* is on equal terms. Two leg-goal rules are implemented. **First cell** (default): the leg ends at the first cell of the next area that A* reaches, which under the multi-goal heuristic is the cheapest entry. **Nearest entry** (the brief's literal rule): the entry cell of the next area nearest to p_t by Manhattan distance is chosen first, then A* plans to it. On maps whose doors are one or two cells wide the two rules choose the same cell, which the ablation confirms."));
body.push(H2("d.6 The algorithm"));
body.push(...figure("pipeline.png", "The two-tier pipeline. The area graph is built once per map; each query pays one abstract search and a chain of confined searches. The dashed loop fires only when a leg fails, which can happen only if assumption A1 is violated."));
body.push(...code([
  "function TWO_TIER(world, G_area, s, g):",
  "    if a(s) == a(g):",
  "        return ASTAR(s, c -> c == g, within = {a(s)}, h = manhattan_to(g))",
  "    banned = {}",
  "    loop:",
  "        seq = ASTAR_ABSTRACT(G_area minus banned, a(s), a(g))   # Tier 1",
  "        if seq is None: return FLAT_ASTAR(s, g)       # only if A1 is violated",
  "        path = [s]; p = s",
  "        for t in 1 .. len(seq) - 1:                                # Tier 2",
  "            leg = ASTAR(p, c -> a(c) == seq[t],",
  "                        within = {seq[t-1], seq[t]},",
  "                        h = min_manhattan_to(Entry(seq[t-1], seq[t])))",
  "            if leg is None:",
  "                banned.add((seq[t-1], seq[t])); restart loop",
  "            path += leg[1:]; p = leg[-1]",
  "        last = ASTAR(p, c -> c == g, within = {a(g)}, h = manhattan_to(g))",
  "        return path + last[1:]",
]));
body.push(P("", { spacing: { after: 60 } }));
body.push(P("**Worked example (Figure 1).** The abstract search from magenta to white has two 2-hop routes; under W1 the yellow route is cheaper (centroid distances 3.9 + 4.1 versus 4.1 + 4.7). Leg 1 from (0,0) reaches yellow at (3,2) with cost 5; leg 2 reaches white at (7,4) with cost 6; the final leg reaches (7,7) with cost 3. Total 14, equal to the Manhattan distance, so the path is optimal. Flat A* expands 14 nodes and the two-tier planner 16 (2 abstract + 14 across legs): on a map this small the hierarchy cannot pay for itself, which is the crossover effect measured in Section (f)."));
body.push(H2("d.7 The W2 (HPA*-style) variant"));
body.push(P("Botea, Müller and Schaeffer's HPA* abstracts a grid into fixed clusters, precomputes the distances between the portal cells of each cluster, and searches a graph whose nodes are portal cells. Our W2 planner is HPA* with semantic areas instead of square clusters. Preprocessing: for every portal cell (a cell adjacent to another area) a breadth-first search confined to its area records its exact distance to every other portal cell of that area, stopping as soon as all are found. Per query: the start and goal are inserted as temporary nodes by one confined search each; Tier 1 is A* over portal cells (plus s and g) where an in-area hop costs the precomputed distance and a cross-boundary hop costs one move; Tier 2 refines each in-area hop with a confined A* to the specific portal cell Tier 1 chose. Because every boundary cell is a portal, no path is ever forced through a bad cell, and on 4-connected maps the planner returned the optimal path on every query we ran. The price is a larger abstract graph (over portal cells, not areas), and the insertion searches, which flood the start and goal areas (visible in Figure 1, right panel). Running W2 on a grid relabelled into uniform 16×16 blocks gives classic HPA*, which we include as the partition comparison."));
body.push(H2("d.8 Properties"));
body.push(...table(["Property", "Flat A*", "Two-tier W1 (greedy legs)", "Two-tier W2 (HPA*-style)"], [
  ["Complete", "yes (finite grid)", "yes, given A1 (fallback otherwise)", "yes, given A1"],
  ["Optimal", "yes (admissible h)", "no: optimal within each leg; the area route (W1) and the entry cell are greedy", "no in general, but only portal-cell forcing can hurt; optimal on all our 4-connected instances"],
  ["Preprocessing", "none", "O(|F|): label areas, find portals", "O(|F|) + a BFS per portal cell, bounded by portals × area size"],
  ["Per-query time", "O(N_f log N_f), N_f = cells with f ≤ C*", "O(k log k) + Σ_t O(n_t log n_t), n_t = cells of two adjacent areas", "as W1, but the abstract graph is over portal cells; plus two insertion searches"],
  ["Memory per query", "open + closed over N_f cells", "one leg at a time: max_t n_t", "same, plus the portal-distance table"],
  ["Blocked route", "re-run from scratch", "ban the area edge, re-run the cheap abstract search", "same; affected portal distances must be recomputed"],
], [1700, 2200, 2730, 2730], "Properties of the planners (k areas, n_t cells in two adjacent areas, C* optimal cost)."));
body.push(P("**Why the greedy planner is not optimal: three independent causes.** (1) //Area-route error:// under W0 or W1 the abstract search may choose a sequence of areas whose real traversal is longer than another's. (2) //Entry-cell greed:// each leg stops at the cheapest cell of the next area, which may be far from where the following leg needs to exit. (3) //Confinement:// the true shortest path may dip into a third area that is not on the chosen sequence. The ablation in Section (f.5) separates these: W0 → W1 → W2 isolates (1), the two leg-goal rules isolate (2), and corridor refinement tests whether any local (2)/(3) detours remain."));
body.push(P("**Why it wins on nodes.** Flat A* with the Manhattan heuristic on a map with walls expands a region whose size grows roughly with the square of the start–goal distance, because the heuristic is weak around obstacles. A refinement leg is confined to two areas, so its expansions are bounded by their size no matter how far apart s and g are, and the total grows roughly linearly with the number of areas on the route."));

// (e) Implementation
body.push(H1("(e) Implementation"));
body.push(H2("e.1 Architecture"));
body.push(...figure("architecture.png", "Module architecture. Four interfaces (`Grid.neighbours/area_of`, `astar()`, `Planner.prepare/plan`, `SearchResult`) were agreed first so the four slices could be developed in parallel against stubs."));
body.push(P("The package `mls` has one module per concept. `grid.py` holds the world and the map format; `partition.py` the area labelling, the A1 repair and the area graph; `generator.py` the seeded rooms-and-corridors generator, the uniform-block partitioner and seeded query sampling; `search.py` a single generic `astar()` (and `bfs()`) that returns a `SearchResult` with path, cost, nodes expanded, nodes generated and peak open-list size; `heuristics.py` the admissible heuristics; `planners/` the four flat baselines, the W0/W1 two-tier planner and the W2 HPA* planner behind one `Planner` interface and a registry; `smoothing.py` the corridor-refinement post-process; `viz.py` and `cli.py` the renders, animation and command line. `experiments/run.py` and `analyze.py` produce every number in this report from `configs/experiment.json`."));
body.push(H2("e.2 Key design decisions"));
body.push(...bullets([
  "**One `astar()` for every search.** The abstract search, every refinement leg and the flat baseline call the same routine, so \"nodes expanded\" means the same thing everywhere: nodes popped from the heap and expanded, stale duplicates skipped. The routine is generic over the node type (cells, areas or portal cells).",
  "**Deterministic tie-breaking.** The heap is keyed on (f, h, insertion counter): ties on f prefer the node closer to the goal, and the counter makes every run reproduce the same node counts.",
  "**Lazy deletion.** A popped entry whose g is stale is skipped rather than decreased in the heap; with a consistent heuristic no node is expanded twice.",
  "**Door cells belong to the corridor.** In generated maps a door is a wall cell assigned to the corridor region it opens from, so a room's entry set is its interior cells next to the door and Tier 1 sees the corridor as the hub.",
  "**Greedy label colouring.** The map format has one character per cell; a 512×512 map has 626 areas and only 62 characters, so labels are assigned by greedy graph colouring (adjacent areas never share a character) and `split_disconnected_areas` separates non-adjacent areas that do. The integer area ids are therefore exact.",
  "**No `hash()`, no global `random`.** Python randomises string hashes per process, which silently broke reproducibility in a first draft of the generator; every random choice now comes from an injected `random.Random(seed)`.",
  "**Corridor refinement instead of string-pulling.** On a 4-connected grid a straight line is not a legal path, so the cheap post-process we test re-runs A* inside a corridor of radius 2 around the hierarchical path; the path can never get worse because the original lies inside the corridor.",
]));
body.push(H2("e.3 Code excerpts"));
body.push(P("The core of the generic search (`search.py`), showing the evaluation function, the tie-breaking key and lazy deletion:"));
body.push(...code([
  "while open_heap:",
  "    f, h, _, node = heapq.heappop(open_heap)",
  "    if node in closed: continue",
  "    if g[node] + weight * h < f - 1e-9: continue          # stale entry",
  "    if is_goal(node):",
  "        return SearchResult(reconstruct(parent, node), g[node],",
  "                            expanded, generated, peak_open)",
  "    closed.add(node); expanded += 1",
  "    for nxt in neighbours(node):",
  "        if nxt in closed: continue",
  "        tentative = g[node] + cost(node, nxt)",
  "        if tentative < g.get(nxt, inf):",
  "            g[nxt] = tentative; parent[nxt] = node",
  "            hn = heuristic(nxt); counter += 1",
  "            heapq.heappush(open_heap, (tentative + weight * hn, hn, counter, nxt))",
  "            generated += 1",
]));
body.push(P("", { spacing: { after: 60 } }));
body.push(P("One refinement leg (`planners/twotier.py`): the neighbour function filters the grid's neighbours to the two allowed areas, and the goal test is membership of the next area:"));
body.push(...code([
  "def leg(self, p, from_area, to_area):",
  "    allowed = {from_area, to_area}",
  "    entries = self.graph.entry_cells(from_area, to_area)",
  "    nbrs = lambda c: [n for n in self.grid.neighbours(c)",
  "                      if self.grid.area_of(n) in allowed]",
  "    if self.leg_goal == 'nearest':",
  "        target = min(entries, key=lambda e: manhattan(p, e))",
  "        return astar(p, lambda c: c == target, nbrs,",
  "                     for_connectivity(target), Grid.step_cost)",
  "    return astar(p, lambda c: self.grid.area_of(c) == to_area, nbrs,",
  "                 min_to_set(entries), Grid.step_cost)",
]));
body.push(P("", { spacing: { after: 60 } }));
body.push(P("The single pass that builds the area graph (`partition.py`): each adjacent pair is visited once by looking only right and up, and portals are stored in both directions so lookups are symmetric:"));
body.push(...code([
  "for c in grid.free_cells():",
  "    a = grid.area_of(c); cells[a].append(c)",
  "    for dx, dy in ((1, 0), (0, 1)):",
  "        n = (c[0] + dx, c[1] + dy)",
  "        if grid.is_free(n) and grid.area_of(n) != a:",
  "            b = grid.area_of(n)",
  "            portals[(a, b)].append((c, n)); portals[(b, a)].append((n, c))",
]));
body.push(P("", { spacing: { after: 60 } }));
body.push(H2("e.4 Testing and continuous integration"));
body.push(P("The suite has 68 pytest tests in eight files and runs in about five seconds; GitHub Actions runs it on Python 3.10 and 3.12 on every push and pull request, followed by a smoke run of the whole experiment pipeline on a two-size configuration. Table 6 lists the tests that carry the most weight."));
body.push(...table(["Test", "What it establishes"], [
  ["`test_figure1_worked_example_from_the_brief`", "The two-tier planner reproduces the brief: route M > Y > W via (3,2) and (7,4), cost 14, three legs, no re-plans"],
  ["`test_all_optimal_planners_agree`", "A*, BFS and Dijkstra return the same cost on random queries over generated maps"],
  ["`test_two_tier_cost_is_never_below_optimal`", "No two-tier variant ever reports a cost below flat A* on the same query (a sanity check on both)"],
  ["`test_two_tier_expands_fewer_nodes_than_flat_on_a_large_map`", "On a 192×192 map the hierarchy wins on at least 8 of 10 long queries"],
  ["`test_fallback_on_a_map_that_violates_a1`", "With A1 enforcement off, a disconnected area triggers the banned-edge re-plan and the flat fallback; with it on, no re-plans occur"],
  ["`test_hpa_on_uniform_blocks`", "The W2 planner is valid on a uniform-block partition (this test found the goal-is-a-portal-cell bug)"],
  ["`test_warehouse_map_matches_script`", "The committed warehouse map equals its generator script, so the two cannot drift apart"],
  ["`test_runner_and_analyze_on_smoke_config`", "The pipeline runs end to end, resumes without duplicating rows, and produces the summary and figures"],
], [4300, 5060], "The most important tests."));
body.push(H2("e.5 Reproducibility"));
body.push(P("`configs/experiment.json` fixes every size, seed and query count; map seed = 1000·seed + size + 7·index and the query sampler is seeded per map, so every planner sees identical (start, goal) pairs. `run.py` writes rows as they are produced and skips rows that already exist, so an interrupted run resumes. `analyze.py` regenerates every table and figure in this report; `experiments/replication.ipynb` is an executed notebook that does the same interactively. Dependencies are pinned in `requirements.txt`; the machine is recorded in `results/environment.txt`."));
body.push(H2("e.6 Difficulties met"));
body.push(...bullets([
  "**Label collisions on large maps.** A first generator used `hash()` of a region key to pick labels; Python randomises string hashes per process, so maps differed between runs with the same seed. Replaced by explicit region ids and greedy colouring (e.2).",
  "**A walled-off office block.** The first hand-drawn warehouse layout left the offices with no door onto a corridor; the planner reported failures. A connectivity test now guards every committed map.",
  "**HPA* and a goal on a portal cell.** When the goal cell was itself a portal, the cost function looked up a start/goal insertion distance before checking for a cross-boundary hop and raised a `KeyError`. Found by the uniform-block test, fixed by ordering the cost cases.",
  "**Same-area queries across a broken area.** With A1 violated, a start and goal in two pieces of one \"area\" have no abstract route to re-plan; the confined search simply failed. Added the flat A* fallback so the planner stays complete whatever the partition.",
]));

// (f) Experiments
body.push(H1("(f) Experiments and results"));
body.push(H2("f.1 Setup"));
body.push(...table(["Factor", "Levels"], [
  ["Grid side N", "16, 32, 64, 128, 256, 512 (rooms per side 2, 2, 3, 5, 8, 12)"],
  ["Maps per size", "5 generated rooms-and-corridors maps, seeds fixed in the config"],
  ["Queries per map", "30 random (start, goal) pairs with Manhattan distance ≥ N/2; identical for every planner"],
  ["Named maps", "Figure 1 (8×8) and the warehouse (60×40), 30 queries each; the brief's (0,0)→(7,7) query first"],
  ["Planners", "flat A*; BFS; Dijkstra; Weighted A* (ε = 1.5); two-tier W0; W1 (first-cell legs); W1 (nearest-entry legs); W1 + corridor refinement; W2 (HPA*, semantic areas); W2 on uniform 16×16 blocks (classic HPA*, sizes ≥ 64)"],
  ["Connectivity", "4 (main run); 8 with octile heuristic for sizes 32–256 (f.8)"],
  ["Timing", "median of 3 timed calls per query (1 at 512); preprocessing timed separately per map and planner"],
  ["Machine", "Intel Xeon 2.30 GHz, Linux, CPython 3.13, single core"],
], [2400, 6960], "Experimental factors. 9,000 generated-map instances per planner plus 60 named-map instances; 9,240 rows in `results/main.csv`."));
body.push(P("Metrics per instance: nodes expanded (the primary measure, deterministic), nodes generated, peak open-list size, runtime in ms, path cost, and the cost ratio = path cost ÷ flat A* cost on the same query (1.0 = optimal). Summary statistics are the mean with a 95 % confidence interval (1.96·s/√n), plus median, 95th percentile and maximum of the cost ratio. Because every planner saw the same queries, planner comparisons use paired statistics: the geometric mean of the per-query node ratio with its CI, and an exact two-sided sign test."));
body.push(H2("f.2 Scaling"));
body.push(...figure("nodes_vs_size.png", "Nodes expanded against grid size (mean and 95 % CI, log–log). Flat A* grows about 3.3× per doubling of the side; two-tier W1 about 1.9×. BFS and Dijkstra lie 9× above A*, showing what the heuristic buys."));
body.push(...figure("runtime_vs_size.png", "Query runtime against grid size. Runtime follows node counts once the per-query overhead of the abstract search is amortised; at 16×16 the two-tier planners are slower than flat A*."));
body.push(...table(["N", "Flat A* nodes", "Two-tier W1 nodes", "Saving", "W2 nodes", "Flat A* ms", "W1 ms", "W2 ms", "Weighted A* nodes"], [
  ["16", "23 ± 3", "22 ± 1", "1.0×", "34 ± 2", "0.05", "0.10", "0.10", "22 ± 2"],
  ["32", "123 ± 17", "43 ± 2", "2.9×", "142 ± 9", "0.24", "0.20", "0.27", "111 ± 15"],
  ["64", "330 ± 53", "81 ± 4", "4.1×", "311 ± 20", "0.68", "0.41", "0.57", "268 ± 38"],
  ["128", "1,254 ± 213", "166 ± 8", "7.6×", "664 ± 38", "2.87", "1.07", "1.22", "686 ± 85"],
  ["256", "5,178 ± 1,144", "322 ± 18", "16.1×", "1,189 ± 70", "13.3", "2.42", "2.50", "1,575 ± 299"],
  ["512", "16,922 ± 3,189", "626 ± 31", "27.0×", "2,414 ± 128", "58.3", "8.09", "5.10", "3,159 ± 403"],
], [600, 1500, 1500, 800, 1200, 1000, 800, 800, 1160], "Scaling on generated maps (mean ± 95 % CI, n = 150 per cell). Full table for all planners in Appendix B.", { size: 18, rightAlign: true }));
body.push(P("Three things stand out. First, the growth rates differ: flat A* multiplies its work by about 3.3 each time the side doubles (near-quadratic in distance), the two-tier planner by about 1.9 (roughly linear in the number of areas on the route), so the saving itself grows with the map, from nothing at 16×16 to 27× at 512×512. Second, the confidence intervals of the two-tier planners are far tighter (±5 % versus ±19 % for flat A* at 512): the hierarchy's work depends on the areas along the route, not on how the heuristic happens to interact with walls. Third, Weighted A* with ε = 1.5 is the strongest non-hierarchical competitor and still expands 5× more nodes than W1 at 512×512; inflating the heuristic does not recover what abstraction gives."));
body.push(P("The paired analysis (Appendix C) confirms the effect is per query, not an artefact of averages: at 512×512 the geometric mean of nodes(W1)/nodes(A*) is 0.086 (95 % CI 0.069–0.107) and W1 expands fewer nodes on 147 of 150 queries (sign test p = 8×10⁻⁴⁰); for W2 the ratio is 0.323 (0.262–0.400), 110 of 150, p = 10⁻⁸."));
body.push(H2("f.3 Crossover"));
body.push(...table(["Variant", "First size with runtime < flat A*", "First size with nodes < flat A*", "Nodes saved at 512×512"], [
  ["Two-tier W0 (hops)", "32", "32", "18.2×"], ["Two-tier W1 (centroids)", "32", "16", "27.0×"],
  ["Two-tier W1, nearest-entry legs", "32", "16", "27.0×"], ["Two-tier W1 + corridor refine", "128", "32", "10.6×"],
  ["Two-tier W2 (HPA*, rooms)", "64", "64", "7.0×"], ["HPA*, uniform 16×16 blocks", "never", "128", "4.0×"],
], [3400, 2200, 2200, 1560], "Crossover sizes: the smallest grid at which each variant beats flat A*."));
body.push(P("On the smallest maps the hierarchy loses on runtime because each query pays a fixed overhead (one abstract search, several heap initialisations) that flat A* does not; on nodes W1 already breaks even at 16×16 because its legs expand almost nothing beyond the path itself. W2 needs 64×64 to pay for its larger abstract graph and insertion searches. Classic HPA* on uniform 16×16 blocks never beats flat A* on runtime on these maps: a block cut by walls becomes several areas, so the abstract graph has 2,271 nodes at 512×512 against 626 for semantic areas, and its preprocessing takes 11 s against 1.2 s."));
body.push(H2("f.4 Path quality"));
body.push(...figure("cost_overhead.png", "Path-cost overhead of the two-tier variants relative to flat A* on identical queries. Top: mean excess length. Bottom: share of queries longer than optimal. W2 and block-HPA* were optimal on every query; W1 averages about 1 % with 6–13 % of queries affected."));
body.push(P("On generated maps the W1 planner's mean overhead is 0.8–1.3 % at every size, with 6–13 % of queries longer than optimal and a worst case of 42 % (one query at 256×256); W0 is worse at 1.4–3.7 % with a worst case of 105 %. W2 and classic HPA* returned the optimal path on every one of their queries. On the warehouse map the picture changes: W1's mean overhead is **10.8 %** and the worst query is 96 % longer than optimal, while W2 remains optimal. The cause is the shape of the areas. The cross-aisles are 52 cells long and 2–3 wide, so the distance between two centroids says little about the real distance between the places a route enters and leaves them, and the first entry cell reached can be at the wrong end of a long aisle. This is the planner's known weakness and the strongest argument for W2 on a real floor, where it costs about 5× the nodes on this small map but still only a few hundred expansions."));
body.push(...figure("savings_vs_overhead.png", "Per-query trade-off at 512×512: node savings against path-cost overhead. W2 (green) sits on the optimal line; W1 (orange) trades a few percent of length for a further 4× saving; Weighted A* (yellow) is dominated on both axes.", 5.4));
body.push(H2("f.5 Ablation"));
body.push(...table(["Variant", "Weight", "Leg goal", "Post-process", "Nodes", "Cost ratio mean", "p95", "max", "ms"], [
  ["Flat A*", "–", "–", "–", "1,254", "1.000", "1.000", "1.000", "2.87"],
  ["Weighted A* (1.5)", "–", "–", "–", "686", "1.010", "1.052", "1.107", "1.59"],
  ["Two-tier W0", "hops", "first cell", "none", "227", "1.033", "1.217", "1.526", "0.67"],
  ["Two-tier W1", "centroid", "first cell", "none", "166", "1.012", "1.075", "1.310", "1.07"],
  ["Two-tier W1", "centroid", "nearest entry", "none", "166", "1.012", "1.075", "1.310", "0.84"],
  ["Two-tier W1", "centroid", "first cell", "corridor r = 2", "430", "1.012", "1.075", "1.310", "2.23"],
  ["Two-tier W2", "portal dist.", "chosen portal", "none", "664", "1.000", "1.000", "1.000", "1.22"],
  ["HPA* 16×16 blocks", "portal dist.", "chosen portal", "none", "680", "1.000", "1.000", "1.000", "4.06"],
], [1700, 1050, 1250, 1300, 800, 1200, 700, 700, 660], "Ablation at 128×128 (n = 150 per row). Cost ratio relative to flat A* on the same query.", { size: 18, rightAlign: true }));
body.push(P("The ablation attributes the overhead to its causes from Section (d.8). Moving from W0 to W1 cuts the mean overhead from 3.3 % to 1.2 % and the 95th percentile from 21.7 % to 7.5 %: the area route (cause 1) is where most of the loss is. The two leg-goal rules produce identical paths on every query, because doors are one or two cells wide and the entry sets are tiny, so cause 2 is negligible on these maps. Corridor refinement changes no path at all while expanding 2.6× the nodes, which shows that what remains is not a local detour that a wider corridor could fix but a different sequence of areas; the post-process is therefore dropped from the recommended configuration. W2 removes all overhead for 4× the nodes of W1, still 1.9× fewer than flat A*."));
body.push(H2("f.6 Query distance and preprocessing"));
body.push(...table(["Start–goal distance ÷ N", "n", "Flat A* nodes", "Weighted A*", "W1 nodes", "W2 nodes", "W1 cost ratio", "W1 % suboptimal"], [
  ["0.50–0.75", "339", "2,607", "909", "162", "755", "1.011", "11 %"],
  ["0.75–1.00", "291", "3,391", "951", "204", "763", "1.012", "11 %"],
  ["1.00–1.50", "256", "6,286", "1,074", "274", "866", "1.009", "10 %"],
  ["1.50+", "14", "6,782", "953", "337", "985", "1.000", "0 %"],
], [1900, 600, 1200, 1100, 1000, 1000, 1200, 1360], "Results by start–goal distance (all sizes pooled).", { size: 18, rightAlign: true }));
body.push(P("Flat A*'s work rises 2.4× across the distance buckets while W1's rises 1.7×, consistent with the growth-rate argument; the W1 overhead does not grow with distance. Preprocessing is a one-off per map: 0.58 s for W1 and 1.18 s for W2 on a 512×512 map (626 areas), against 11.1 s for uniform 16×16 blocks (2,271 areas); it is amortised after a few dozen queries."));
body.push(...figure("prep_time.png", "One-off preprocessing time per map. W1 and W2 grow roughly linearly with cells; uniform blocks pay for a BFS from each of up to 64 portal cells per block.", 5.2));
body.push(H2("f.7 Statistical summary and objectives"));
body.push(P("All four objectives from Section (b) are met on generated maps: (i) 100 % success on all 9,240 instances; (ii) 16× fewer nodes at 256×256 (target ≥ 5×); (iii) mean cost ratio 1.010 (target < 1.10), although the warehouse map's 1.108 shows the target is partition-dependent; (iv) the runtime crossover is at 32×32 for W1 and 64×64 for W2. The paired sign tests reject the null of no node saving at every size from 32×32 upward for W1 (p ≤ 6×10⁻¹⁴) and from 256×256 upward for W2."));
body.push(H2("f.8 8-connectivity"));
body.push(P("Repeating sizes 32–256 with 8-connected moves and the octile heuristic (`results/octile/`) gives the same picture with slightly larger overheads: at 256×256, W1 expands 369 ± 23 nodes against 9,051 ± 1,303 for flat A* (25× fewer) at a mean overhead of 3.1 % (worst 40 %); W2 expands 1,354 ± 78 (6.7× fewer) and is within 0.5 % of optimal on every query, no longer exactly optimal because with diagonal moves a path forced through a portal cell can cost a fraction more. On the warehouse, W1's overhead rises to 14.8 % and W2's to 1.0 %."));
body.push(H2("f.9 Threats to validity"));
body.push(...bullets([
  "**Generator bias.** Rooms-and-corridors maps are the best case for a semantic partition. The uniform-block condition and the hand-built warehouse are the counterweights, and the warehouse is where W1 looks worst.",
  "**Timing noise.** Pure-Python timings on a shared machine; nodes expanded is the primary metric and runtimes carry confidence intervals. Absolute times would change by 10–100× in a compiled implementation; ratios should not.",
  "**Query distribution.** Only long queries (≥ N/2) were sampled, by design; short queries favour flat A* and would move the crossover up.",
  "**One machine, one language, mostly 4-connectivity.** The 8-connected run is a partial replication, not a full factorial.",
]));

// (g) Limitations
body.push(H1("(g) Limitations and reflection"));
body.push(H2("Limitations of the method"));
body.push(...bullets([
  "Quality depends entirely on the partition. One huge area degenerates to flat A*; long thin areas make the W1 route choice unreliable (10.8 % mean overhead on the warehouse against about 1 % on generated maps).",
  "W0/W1 suboptimality is unbounded in adversarial maps. Only W2 is bounded, by the portal-cell constraint, and it pays with a larger abstract graph.",
  "W2's per-query insertion search floods the start and goal areas (Figure 1, right); in very large open areas this erodes its advantage. Bounding the insertion search or caching insertion distances per area would fix it.",
  "Static maps and a single robot; dynamic replanning (D* Lite) and multi-robot reservations are out of scope.",
  "Corridor refinement was a null result on 4-connected maps; string-pulling only makes sense with diagonal moves.",
]));
body.push(H2("Limitations of the evaluation"));
body.push(...bullets([
  "The generator favours our partition; a real floor plan traced from a drawing would be a stronger test than one hand-built by us.",
  "No comparison with Jump Point Search or with a compiled HPA* implementation; absolute runtimes are only indicative.",
  "The two leg-goal rules could not be distinguished because every door in our maps is narrow; maps with wide openings would be needed to test cause 2.",
]));
body.push(H2("What we would do differently"));
body.push(P("Decide the door-cell ownership rule and the connectivity default in the first week rather than discovering their consequences in tests; write the connectivity test before drawing the first map by hand; and measure before optimising, because corridor refinement was built on the assumption that the overhead was local, which the ablation disproved in an afternoon. Each member's individual reflection statement expands on the decisions and problems in their own slice."));

// (h) Conclusion
body.push(H1("(h) Conclusion and future work"));
body.push(P("A two-tiered search over areas and cells does what the brief anticipates: on maps with a sensible partition it expands an order of magnitude fewer nodes than flat A* and the advantage grows with the map, from break-even at 16×16 to 27× at 512×512, at a path-cost overhead of about 1 %. The HPA*-style W2 variant, which precomputes distances between portal cells, removes the overhead entirely on 4-connected maps while still expanding 7× fewer nodes than flat A*. The trade-off is clear: W1 when every millisecond counts and a few percent of path length is acceptable; W2 when paths must be optimal and the one-second preprocessing can be amortised. The method's limit is the partition: on the warehouse map's long thin cross-aisles the cheap centroid weight mis-ranks routes and only W2 is safe."));
body.push(P("Future work, in order of value: learn the partition from the map (room and corridor segmentation) instead of taking it as given; prune W2's portal cells to one representative per doorway to shrink its abstract graph; bound or cache the W2 insertion searches; repair a single leg D*-Lite-style when an aisle is blocked at run time; reserve area-graph edges over time for a fleet of robots; and port the planner to C++ for the inch-resolution building map of the brief."));

// (i) References
body.push(H1("(i) References"));
body.push(...numbered([
  "S. Russell and P. Norvig, //Artificial Intelligence: A Modern Approach//, 4th ed. Pearson, 2021, chs. 3–4.",
  "P. E. Hart, N. J. Nilsson and B. Raphael, \"A formal basis for the heuristic determination of minimum cost paths,\" //IEEE Transactions on Systems Science and Cybernetics//, vol. 4, no. 2, pp. 100–107, 1968.",
  "A. Botea, M. Müller and J. Schaeffer, \"Near optimal hierarchical path-finding,\" //Journal of Game Development//, vol. 1, no. 1, pp. 7–28, 2004.",
  "I. Pohl, \"Heuristic search viewed as path finding in a graph,\" //Artificial Intelligence//, vol. 1, no. 3–4, pp. 193–204, 1970.",
  "S. Koenig and M. Likhachev, \"D* Lite,\" in //Proc. AAAI//, 2002, pp. 476–483.",
  "D. Harabor and A. Grastien, \"Online graph pruning for pathfinding on grid maps,\" in //Proc. AAAI//, 2011, pp. 1114–1119.",
  "CSCI218 Foundations of Artificial Intelligence, lecture notes: Intelligent Agents; Problem Solving by Search; Heuristic Search. University of Wollongong in Dubai, Autumn 2026.",
  "[Add one source on AGV or mobile-robot routing in warehouses to anchor the scenario, e.g. a survey article; verify before submission.]",
]));

// (j) Appendices
body.push(H1("(j) Appendices"));
body.push(H2("Appendix A: Repository and contributions"));
body.push(P("Repository: https://github.com/[org]/multilayer-search, commit [hash]. The repository contains the package `mls`, the maps, the configuration, the experiment scripts, all results and figures, the executed replication notebook and the test suite. Table 11 is the group's contribution table; each entry is backed by that member's commits and expanded in their individual reflection statement."));
body.push(...table(["Member", "Code", "Tests", "Report sections", "Share"], [
  ["M1 [name]", "`grid.py`, `partition.py`, `generator.py`, `maps/`, `scripts/make_warehouse.py`", "`test_grid`, `test_partition`, `test_generator`, `test_warehouse`", "(c), (d.1)–(d.3)", "25 %"],
  ["M2 [name]", "`search.py`, `heuristics.py`, `planners/base.py`, `planners/flat.py`, `planners/twotier.py`", "`test_search`, `test_twotier`", "(d.4)–(d.8), (e.2)–(e.3)", "25 %"],
  ["M3 [name]", "`planners/hpa.py`, `smoothing.py`, `experiments/run.py`, `experiments/analyze.py`, configs, notebook", "`test_pipeline` (runner, smoothing)", "(f)", "25 %"],
  ["M4 [name]", "`viz.py`, `cli.py`, CI workflow, README, `scripts/make_diagrams.py`", "`test_pipeline` (CLI, viz), code review of all PRs", "(a), (b), (e.1), (e.4)–(e.6), (g), (h), (i), (j), editing", "25 %"],
], [1300, 3300, 2100, 1900, 760], "Contribution table (to be reconciled with the Git log before submission)."));
body.push(H2("Appendix B: Full results table"));
const summary = fs.readFileSync(path.join(REPO, "results", "summary.md"), "utf8").trim().split("\n").slice(2)
  .map((l) => l.split("|").slice(1, -1).map((s) => s.trim()));
body.push(...table(["N", "Planner", "n", "Nodes expanded (mean ± 95 % CI)", "Runtime ms (mean ± CI)", "Cost ratio mean", "median", "max"],
  summary, [500, 2300, 450, 1900, 1700, 900, 800, 810], "All planners and sizes on generated maps (`results/summary.md`).", { size: 17, rightAlign: true, rightFrom: 2 }));
body.push(H2("Appendix C: Paired comparison with flat A*"));
const paired = fs.readFileSync(path.join(REPO, "results", "paired_tests.md"), "utf8").trim().split("\n").slice(4)
  .map((l) => l.split("|").slice(1, -1).map((s) => s.trim()));
body.push(...table(["N", "Variant", "n", "Geometric mean nodes ratio", "95 % CI", "Queries with fewer nodes", "Sign-test p"],
  paired, [500, 2500, 450, 1600, 1700, 1500, 1110], "Paired per-query node ratio against flat A* on identical queries (`results/paired_tests.md`).", { size: 17, rightAlign: true, rightFrom: 2 }));
body.push(H2("Appendix D: Maps"));
body.push(P("Figure 1 of the brief, encoded in `maps/figure1.map` (top row first, so the last line is y = 0; `#` blocked, letters are areas):"));
body.push(...code(["PPP#WWWW", "PPPWWWWW", "PPP#WWWW", "#P#####W", "MMM#Y#YY", "MMMYYYYY", "MMM##B##", "MMM#BBB#"]));
body.push(P("", { spacing: { after: 60 } }));
body.push(P("The warehouse map is built by `scripts/make_warehouse.py` (60×40; the script's docstring documents every zone) and rendered in Figure 1 of this report. Generated maps are produced by `mls generate N --seed k --rooms r`."));
body.push(H2("Appendix E: Configuration and environment"));
body.push(P("`configs/experiment.json` (main run) and `configs/experiment_8conn.json` (8-connected run) are in the repository. Environment of the reported timings (`results/environment.txt`): CPython 3.13.18, Linux x86_64, Intel Xeon Processor @ 2.30 GHz."));
body.push(H2("Appendix F: Demonstration script"));
body.push(...numbered([
  "`mls show maps/figure1.map -v` — the brief's sample world, its five areas and five edges with their portals.",
  "`mls plan maps/figure1.map 0 0 7 7 --planner astar --planner twotier --show` — the brief's query; both cost 14, the two-tier route M > Y > W printed on the map.",
  "`mls show maps/warehouse.map` then `mls plan maps/warehouse.map 10 2 50 37 --planner astar --planner twotier --planner twotier-W2` — the warehouse, area route R > S > q > M > h > N > D.",
  "`mls render maps/warehouse.map 10 2 50 37 --planner astar --planner twotier --planner twotier-W2 -o demo.png` — side-by-side expansions (Figure 1 of this report).",
  "`mls animate maps/warehouse.map 10 2 50 37 -o anim` — the abstract route, then each leg accumulating (GIF).",
  "`mls generate 256 --seed 3 --rooms 8 -o big.map` then `mls plan big.map 5 5 250 250 --planner astar --planner twotier --planner wastar` — the scaling effect live: tens of thousands of nodes against a few hundred.",
]));

// ---------------------------------------------------------------- document
const numberingConfigs = [{ reference: "bul", levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 270 } } } }] }];
for (let i = 1; i <= numRef; i++) numberingConfigs.push({ reference: `num${i}`, levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 360 } } } }] });

const doc = new Document({
  creator: "CSCI218 group",
  title: "Multi-Layered Search for Warehouse Robot Path Planning",
  features: { updateFields: true },
  styles: {
    default: { document: { run: { font: FONT, size: 22 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true, run: { font: FONT, size: 32, bold: true, color: "1F3864" }, paragraph: { spacing: { before: 360, after: 160 }, keepNext: true, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true, run: { font: FONT, size: 26, bold: true, color: "2E5496" }, paragraph: { spacing: { before: 240, after: 100 }, keepNext: true, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true, run: { font: FONT, size: 23, bold: true }, paragraph: { spacing: { before: 160, after: 80 }, keepNext: true, outlineLevel: 2 } },
    ],
  },
  numbering: { config: numberingConfigs },
  sections: [{
    properties: { page: { margin: { top: 1134, bottom: 1134, left: 1247, right: 1247 } } },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ children: ["Page ", PageNumber.CURRENT], font: FONT, size: 18, color: "666666" })] })] }) },
    children: body,
  }],
});

Packer.toBuffer(doc).then((buf) => {
  const out = path.join(__dirname, "CSCI218_Topic4_Report.docx");
  fs.writeFileSync(out, buf);
  console.log("wrote", out, `(${figN} figures, ${tabN} tables)`);
});

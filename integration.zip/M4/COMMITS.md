# Your push guide

You are **Member 4 (M4): visualisation, CLI, CI, README and report**. This folder holds exactly the files you commit. Copy them into your clone of the
repository at the same relative paths, then make the commits below **in this order, under your own
GitHub account**, on your own branch, and open a pull request.

Before you start, once on your machine:

```
git config --global user.name  "Your Name"
git config --global user.email "the email on your GitHub account"
```

Then:

```
git clone https://github.com/<org>/multilayer-search.git   # (M1: see step 0 instead)
cd multilayer-search
git checkout main && git pull
git checkout -b feature/integration
```

For each commit: copy that commit's files in, run `pytest`, then `git add <those files>` and
`git commit -m "<message>"`. When all commits are done: `git push -u origin feature/integration`, open a pull
request on GitHub, request **M1** as reviewer, and merge after approval.

**Wait until M3's pull request is merged.** `tests/test_pipeline_ADD_TO_END.py` is not a file to commit: append its two tests to the END of the existing `tests/test_pipeline.py`, then delete the helper file.

## Your commits

1. `Visualiser: renders and leg-by-leg animation`  
   files: src/mls/viz.py, tests/test_pipeline.py (with the two appended tests)

2. `Command-line interface`  
   files: src/mls/cli.py

3. `CI workflow`  
   files: .github/workflows/tests.yml

4. `Demo renders and report diagrams`  
   files: scripts/make_diagrams.py, results/figures/warehouse_demo.png, figure1_demo.png, pipeline.png, architecture.png

5. `README`  
   files: README.md

6. `Report`  
   files: docs/report/CSCI218_Topic4_Report.docx, docs/report/build_report.js


## Your reflection statement

`docs/report/Reflection_M4_draft.docx` is a draft. Rewrite it in your own words, replace every [bracket], rename it to
`Reflection_M4.docx`, and commit it yourself (it is evidence of your individual work):

```
git add docs/report/Reflection_M4.docx && git commit -m "Reflection statement (M4)"
```

## Be ready to explain in the viva

How expanded cells are captured by tracing `Grid.neighbours`; what each CLI command does; what CI runs and why a smoke run of the pipeline is included; how every figure in the report is regenerated; the headline numbers of the report and where each comes from.

# Multi-Layered Search for a warehouse robot (CSCI218 Topic 4)

A two-tiered (hierarchical) path planner for grid worlds, compared against flat
A* and other baselines on maps from 8x8 to 512x512. The real-world scenario is a
mobile robot on a logistics-warehouse floor (`maps/warehouse.map`), where racking
aisles, cross-aisles and dock aprons are natural *areas* for the abstract tier.

| Flat A* vs two-tier on the warehouse | Nodes expanded vs map size |
| --- | --- |
| ![](results/figures/warehouse_demo.png) | ![](results/figures/nodes_vs_size.png) |

## Install, test, reproduce

```bash
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -e ".[dev,analysis]"
pytest                                                 # ~60 tests, < 30 s
python -m experiments.run                              # all planners x all maps -> results/main.csv (~10 min)
python -m experiments.analyze                          # results/summary.*, ablation, crossover, distance buckets, paired tests, figures/
python -m experiments.run --config configs/experiment_8conn.json && \
  python -m experiments.analyze --results results/octile/main.csv --prep results/octile/prep.csv --outdir results/octile
python scripts/make_diagrams.py                        # results/figures/pipeline.png, architecture.png
jupyter nbconvert --execute --to notebook experiments/replication.ipynb   # or open it
```

Everything is seeded from `configs/experiment.json`, so the CSVs and figures in
`results/` regenerate byte-for-byte apart from timings. `run.py` resumes, so an
interrupted run can simply be restarted.

## Command line

```bash
mls show maps/figure1.map                                   # ASCII map + area graph
mls plan maps/warehouse.map 10 2 50 37 --planner astar --planner twotier --planner twotier-W2
mls plan maps/figure1.map 0 0 7 7 --planner twotier --show  # the brief's example, path drawn
mls generate 128 --seed 3 --rooms 5 -o maps/gen128.map      # seeded rooms-and-corridors map
mls render maps/warehouse.map 10 2 50 37 -o results/figures/warehouse_demo.png
mls animate maps/warehouse.map 10 2 50 37 -o results/figures/warehouse_anim   # frames + GIF, leg by leg
```

(`mls` is installed by `pip install -e .`; `python -m mls.cli` works without installing.)

## How it works

1. **Preprocessing (once per map).** Every free cell carries an area label.
   `partition.build_area_graph` labels areas, splits any area that is not
   4-connected (assumption A1), and finds every *portal* (pair of adjacent cells
   in different areas) in one pass. Areas are nodes of the *area graph*; two
   areas are joined if they share a portal.
2. **Tier 1: abstract search.** A* over the area graph from `area(start)` to
   `area(goal)`. Edge weight W0 = 1 per hop, W1 = Manhattan distance between
   area centroids (default), W2 = exact in-area distances between portal cells,
   precomputed (HPA*-style, `planners/hpa.py`). Heuristic: Manhattan distance
   from the area's closest cell to the goal (admissible).
3. **Tier 2: refinement.** For each consecutive pair of areas, one small A*
   confined to those two areas, ending at the first cell of the next area it
   reaches (or at the nearest entry cell, `leg_goal="nearest"`, the brief's
   literal rule). A final leg inside the goal's area reaches the goal. Legs are
   concatenated; nodes expanded are summed over both tiers.
4. **Fallback.** If a leg fails (only possible when A1 is violated), the area
   edge is banned and Tier 1 re-plans; if no abstract route is left, a flat A*
   runs so the planner stays complete.

Flat A* is complete and optimal. The two-tier planner is complete, and *not*
optimal in general: with W0/W1 the area route can be wrong and the entry cell
greedy; with W2 the path is only forced through portal cells. The experiments
measure exactly that trade-off.

## Repository map

```
maps/figure1.map            the brief's 8x8 sample (y up, (0,0) lower-left)
maps/warehouse.map          60x40 warehouse floor, built by scripts/make_warehouse.py
configs/experiment.json     sizes, seeds, queries per map, planners
src/mls/grid.py             Grid: map format, neighbours (4/8-conn), area_of, step_cost
src/mls/partition.py        label_areas, split_disconnected_areas, AreaGraph, build_area_graph
src/mls/generator.py        rooms_and_corridors (seeded), uniform_blocks, random_query
src/mls/search.py           generic astar() and bfs(); SearchResult with expanded/generated/peak_open
src/mls/heuristics.py       manhattan, octile, euclidean, zero, min_to_set
src/mls/planners/base.py    Planner interface + registry (make("twotier", ...))
src/mls/planners/flat.py    FlatAStar, WeightedAStar, Dijkstra, BFS
src/mls/planners/twotier.py TwoTierPlanner (W0/W1, leg_goal first/nearest, fallback)
src/mls/planners/hpa.py     HPAPlanner (W2 portal distances; HPA* on uniform blocks)
src/mls/smoothing.py        corridor_refine: cheap post-optimisation of a hierarchical path
src/mls/viz.py              matplotlib renders, side-by-side expansions, leg-by-leg animation
src/mls/cli.py              mls show / plan / generate / render / animate
experiments/run.py          the runner (seeded, resumable, CSV)
experiments/analyze.py      statistics tables (summary, ablation, crossover, distance buckets, paired tests) + figures
experiments/replication.ipynb  executed notebook reproducing the headline numbers
scripts/make_diagrams.py    pipeline and architecture diagrams for the report
results/                    main.csv, prep.csv, summary.*, ablation/crossover/distance_buckets/paired_tests.md, environment.txt, figures/
results/octile/             the same for the 8-connected run (configs/experiment_8conn.json)
tests/                      pytest suite incl. the brief's Figure 1 example and a broken-map fallback
```

## Map format

One text row per line, **top row first**; `#` blocked, any other character is
a free cell and names its area. Coordinates are `(x, y)` with `y` pointing up,
matching Figure 1 of the brief. Everything outside the rectangle is blocked
(the brief's "perimeter is always blocked" rule). Large generated maps reuse
characters: adjacent areas never share one, and `split_disconnected_areas`
separates non-adjacent ones, so the integer area ids are exact.

## Design decisions worth knowing for the viva

- **4-connectivity by default; 8-connectivity is a flag** (`Grid(..., connectivity=8)`,
  octile heuristic, no corner cutting). The main results are 4-connected; `results/octile/`
  repeats sizes 32-256 with 8-connectivity (W1 still saves 25x nodes at 256x256, ~3% overhead;
  W2 is within 0.5% of optimal).
- **One `astar()` for everything** so node counts are comparable across planners.
- **Door cells belong to the corridor**, so the entry set of a room is its
  interior cells next to the door and Tier 1 sees the corridor as the hub.
- **W1 vs W2.** W1 is cheap and gives the largest node savings but ~1% mean
  path overhead; W2 is optimal on our maps but its abstract graph is over
  portal cells, so it expands more nodes per query and needs O(portals x area)
  preprocessing. Uniform 16x16 blocks (classic HPA*) are worse than semantic
  areas on both counts.
- **Why no `hash()`, no global `random`.** Both vary between processes; every
  random choice comes from an injected `random.Random(seed)`.

## Team

| Member | Owns |
| --- | --- |
| M1 | grid, partition, generator, maps, warehouse script |
| M2 | search, heuristics, flat planners, two-tier planner |
| M3 | HPA* variant, smoothing, experiments, analysis |
| M4 | viz, CLI, CI, README, report assembly |
